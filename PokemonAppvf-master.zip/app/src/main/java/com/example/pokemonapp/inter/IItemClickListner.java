package com.example.pokemonapp.inter;

import android.view.View;

public interface IItemClickListner {
    void onClick(View view,int position);
}
